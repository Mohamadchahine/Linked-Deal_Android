package com.ChahineCodiTech.linkeddeal;

public interface ShopListInterface {

    void onclick(int position);

}
