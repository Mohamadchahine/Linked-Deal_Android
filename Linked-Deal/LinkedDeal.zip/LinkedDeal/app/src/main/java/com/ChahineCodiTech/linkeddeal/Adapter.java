package com.ChahineCodiTech.linkeddeal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;



public class Adapter extends RecyclerView.Adapter<Adapter.RCViewHolder> {

    Context context;
    ArrayList<UDataClass> datausersList;

    private final ShopListInterface shopListInterface;
    public Adapter(@NonNull Context context, ArrayList<UDataClass> datausersList, ShopListInterface shopListInterface) {


        this.context=context;
        this.datausersList=datausersList;
        this.shopListInterface=shopListInterface;
    }


    @NonNull
    @Override
    public Adapter.RCViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.recycler_shoplist, parent, false);
        return new Adapter.RCViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.RCViewHolder holder, int position) {
        UDataClass model = datausersList.get(position);
        holder.image.setImageBitmap(model.bitmap);
        holder.shopname.setText(model.CName);

    }

    @Override
    public int getItemCount() {
        return datausersList.size();
    }

    public class RCViewHolder extends RecyclerView.ViewHolder{

        TextView shopname;
        ImageView image;

        public RCViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.logo);
            shopname = itemView.findViewById(R.id.shopname);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(shopListInterface != null){
                        int pos = getAdapterPosition();

                        shopListInterface.onclick(pos);
                    }
                }
            });



        }
    }
}