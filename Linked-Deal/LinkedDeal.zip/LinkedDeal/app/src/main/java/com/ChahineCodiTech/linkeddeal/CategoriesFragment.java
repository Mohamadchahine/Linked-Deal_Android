package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class CategoriesFragment extends Fragment implements ShopListInterface{

    String url="https://linkeddeal.000webhostapp.com/Scripts/CategoryView.php",CatID;

    RecyclerView recyclerView;
    ArrayList<CategoriesCode> modelArrayList;
    CategoriesAdapter adapt;
    CategoriesCode cat;


    LinearLayoutManager linearLayoutManager;
    JSONArray jsonArray;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_categories, container, false);

        recyclerView=v.findViewById(R.id.catlistguest);


        recyclerView.setHasFixedSize(true);

        modelArrayList = new ArrayList<>();
        adapt = new CategoriesAdapter(getContext(), modelArrayList,this);

        linearLayoutManager = new GridLayoutManager(getActivity(), 1); // Set span count to 1
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapt);

        getData();
        // Update the adapter and notifyDataSetChanged() method
        adapt = new CategoriesAdapter(getContext(), modelArrayList,this);
        recyclerView.setAdapter(adapt);
        adapt.notifyDataSetChanged();


        return v;
    }



    private void getData() {
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                modelArrayList.clear();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    jsonArray = jsonObject.getJSONArray("data");
                    if (success.equals("1")){
                        for(int i=0; i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            String CategoryName = object.getString("Category_Name");
                            //CatID= object.getString("Category_ID");

                            cat = new CategoriesCode(CategoryName);
                            modelArrayList.add(cat);
                            adapt.notifyDataSetChanged();
                        }
                    }

                }catch (Exception e){
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }

        });
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }

    @Override
    public void onclick(int position) {
        Bundle bundle = new Bundle();
        JSONObject object = null;
        try {
            object = jsonArray.getJSONObject(position);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        try {
            CatID = object.getString("Category_ID");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        bundle.putString("CatID", CatID);


        Fragment fragment = new ProductsCatFilterFragment();
        fragment.setArguments(bundle);

        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }

    }
}