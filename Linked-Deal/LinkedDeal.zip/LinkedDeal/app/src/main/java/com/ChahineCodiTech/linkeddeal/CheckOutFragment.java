package com.ChahineCodiTech.linkeddeal;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class CheckOutFragment extends Fragment {


    EditText Name,Phone,Address,Note;
    String sName,sPhone,sAddress,sNote;
    Button submit;

    String orderdb="https://linkeddeal.000webhostapp.com/Scripts/AddOrder.php"
            ,orderitemdb="https://linkeddeal.000webhostapp.com/Scripts/AddOrderItem.php";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_check_out, container, false);

        Name=v.findViewById(R.id.guestName);
        Phone=v.findViewById(R.id.guestPhone);
        Address=v.findViewById(R.id.guestAddress);
        Note=v.findViewById(R.id.guestNote);
        submit = v.findViewById(R.id.SubmitOrder);
        
        
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Submit();
            }
        });
        return v;
    }

    private void Submit() {
        addOrder();
        int z= ProdArray.getProducts().size();
        for(int i=0; i<z; i++){
            addOrderItem(ProdArray.getProducts().get(i));
        }
        Fragment fragment = new HomeFragment();
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }


    }

    private void addOrderItem(OItemCode oItemCode) {

        String PID = oItemCode.ID;
        String Quantity = oItemCode.Quantity;
        String Total = oItemCode.Total;

        StringRequest request = new StringRequest(Request.Method.POST, orderitemdb, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("PID", PID);
                parms.put("Quantity", Quantity);
                parms.put("Total", Total);
                return parms;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
        ProdArray.clearProducts();
    }

    private void addOrder() {
        if (Name.getText().toString().isEmpty() || Phone.getText().toString().isEmpty() ||
                Address.getText().toString().isEmpty() ) {
            Toast.makeText(getContext(), "Please Fill All Fields ", Toast.LENGTH_SHORT).show();
        } else {

            OItemCode o = ProdArray.getProducts().get(0);
            String Seller = o.getSeller();
            sName = Name.getText().toString();
            sPhone = Phone.getText().toString();
            sAddress = Address.getText().toString();
            sNote = Note.getText().toString();

            orderdb+="?UserID="+Seller;
            StringRequest request = new StringRequest(Request.Method.POST, orderdb, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    Name.setText("");
                    Phone.setText("");
                    Address.setText("");
                    Note.setText("");
                    Toast.makeText(getContext(), "Order Placed", Toast.LENGTH_SHORT).show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("Name", sName);
                    parms.put("Phone", sPhone);
                    parms.put("Address", sAddress);
                    parms.put("Note", sNote);


                    return parms;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            requestQueue.add(request);
        }
    }




}