package com.ChahineCodiTech.linkeddeal;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;


public class ProductsEditFragment extends Fragment {


    String PID,UserID;

    Button update,delete;
    String PName,PQuantity,PPrice,PDesc,imageUrl;
    String UPName,UPQuantity,UPPrice,UPDesc;

    EditText ePName,ePQuantity,ePPrice,ePDesc;
    ImageView img;
    String viewurl="https://linkeddeal.000webhostapp.com/Scripts/ProductsEditView.php",
            updateurl="https://linkeddeal.000webhostapp.com/Scripts/ProductsEditUpdate.php",
                updateimg="https://linkeddeal.000webhostapp.com/Scripts/prodimageupdate.php",
                del="https://linkeddeal.000webhostapp.com/Scripts/DeleteProducts.php";
    Uri selecteduri;
    Bitmap bitmp;
    String encodeImage;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_products_edit, container, false);

        Bundle bundle = getArguments();
        PID = bundle.getString("PID", "x");
        UserID = SellerDashboard.getUserID();


        img=v.findViewById(R.id.Productimgupdate);
        ePName=v.findViewById(R.id.Productnameupdate);
        ePQuantity=v.findViewById(R.id.Productquantityupdate);
        ePPrice=v.findViewById(R.id.Productpriceupdate);
        ePDesc=v.findViewById(R.id.Productdescupdate);
        update=v.findViewById(R.id.updateproductsbtn);
        delete=v.findViewById(R.id.delproductsbtn);


        ProductView();

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdateProduct();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteProduct();
            }
        });

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChooseImage();

            }
        });

        return v;
    }


    private void deleteProduct() {

        StringRequest request = new StringRequest(Request.Method.POST, del, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.equalsIgnoreCase("Deleted Products!")){
                    Toast.makeText(getContext(), "Deleted Products!", Toast.LENGTH_SHORT).show();
                    Fragmentmove(new SellerProductsFragment());
                }else{
                    Toast.makeText(getContext(), "Failed", Toast.LENGTH_SHORT).show();
                }
            }

            private void Fragmentmove(Fragment fragment) {
                FragmentManager fragmentManager = getFragmentManager();
                if (fragmentManager != null) {
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.frame_layout, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                }
            }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("PID", PID);

                return parms;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }


    private void ProductView() {
        viewurl += "?UserID="+UserID + "&PID="+PID;
        JsonArrayRequest request = new JsonArrayRequest( viewurl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject jsonObject = response.getJSONObject(0);
                    PName = jsonObject.getString("PName");
                    PQuantity = jsonObject.getString("Quantity");
                    PPrice = jsonObject.getString("Price");
                    PDesc = jsonObject.getString("Description");

                    ePName.setText(PName);
                    ePQuantity.setText(PQuantity);
                    ePPrice.setText(PPrice);
                    ePDesc.setText(PDesc);

                    imageUrl = jsonObject.getString("imageUrl");
                    Picasso.get().load(imageUrl).into(img);
                } catch (Exception e) {
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("UserID", UserID);

                return parms;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }


    private void UpdateImage() {

        updateimg += "?UserID="+UserID + "&PID="+PID;

        StringRequest request = new StringRequest(Request.Method.POST, updateimg, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();
                ProductView();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();
                parms.put("Image",encodeImage);
                return parms;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }


    private void UpdateProduct() {

        UPName = ePName.getText().toString();
        UPQuantity = ePQuantity.getText().toString();
        UPPrice = ePPrice.getText().toString();
        UPDesc = ePDesc.getText().toString();

        updateurl += "?UserID="+UserID + "&PID="+PID;

        StringRequest request = new StringRequest(Request.Method.POST, updateurl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();
                ProductView();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("PName", UPName);
                parms.put("Quantity", UPQuantity);
                parms.put("Price", UPPrice);
                parms.put("Description", UPDesc);

                return parms;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);



    }
    private void ChooseImage() {
        ImagePicker.with(this)
                .cropSquare()	    			//Crop image(Optional), Check Customization for more option
                .compress(1024)			//Final image size will be less than 1 MB(Optional)
                .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                .start();
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && data != null) {
            selecteduri = data.getData();
            try {
                InputStream inputStream = requireContext().getContentResolver().openInputStream(selecteduri);
                bitmp = BitmapFactory.decodeStream(inputStream);
                img.setImageURI(selecteduri);
                ImageStore(bitmp);

                // You now have the bitmap and the encoded string
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void ImageStore(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte [] imagebyte = stream.toByteArray();
        encodeImage = android.util.Base64.encodeToString(imagebyte, Base64.DEFAULT);
        UpdateImage();
    }


}