package com.ChahineCodiTech.linkeddeal;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class ShopDeleteFragment extends Fragment {


    TextView id, name, phone, email;
    ImageView img;

    Button delbtn;

    String did, dname, demail, dphone;
    String url="https://linkeddeal.000webhostapp.com/Scripts/DeleteUser.php";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_shop_delete, container, false);

        id = v.findViewById(R.id.delCID);
        name = v.findViewById(R.id.delCName);
        phone = v.findViewById(R.id.delCphone);
        email = v.findViewById(R.id.delCEmail);

        delbtn = v.findViewById(R.id.ProfileDelete);

        delbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteUser();
            }
        });

        // Retrieve the position argument from the Bundle
        Bundle bundle = getArguments();
        dname = bundle.getString("name", "x");
        dphone = bundle.getString("phone", "");
        demail = bundle.getString("email", "");
        did = bundle.getString("id", "x");

        id.setText(did);
        name.setText(dname);
        phone.setText(dphone);
        email.setText(demail);
        return v;
    }

    public void DeleteUser(){
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.equalsIgnoreCase("Deleted User!")){
                    Toast.makeText(getContext(), "Deleted User!", Toast.LENGTH_SHORT).show();
                    Fragmentmove(new ViewSellersFragment());
                }else{
                    Toast.makeText(getContext(), "Failed", Toast.LENGTH_SHORT).show();
                }
            }

            private void Fragmentmove(Fragment fragment) {
                FragmentManager fragmentManager = getFragmentManager();
                if (fragmentManager != null) {
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.frame_layout, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                }
            }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("UserID", did);

                return parms;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }

}