package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class ShopFragment extends Fragment implements ShopListInterface{


    RecyclerView listSeller;
    Adapter uadap;
    ArrayList<UDataClass> dataClassArrayList;
    UDataClass uDataClass;

    String url="https://linkeddeal.000webhostapp.com/Scripts/ViewUsers.php",did;


    Bitmap bitmp;

    LinearLayoutManager linearLayoutManager;
    JSONArray jsonArray;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_shop, container, false);

        listSeller = v.findViewById(R.id.ShopsList1);

        listSeller.setHasFixedSize(true);

        dataClassArrayList = new ArrayList<>();
        uadap = new Adapter(getContext(),dataClassArrayList,this);

        listSeller.setAdapter(uadap);
        linearLayoutManager = new GridLayoutManager(getActivity(), 1); // Set span count to 1
        listSeller.setLayoutManager(linearLayoutManager);
        listSeller.setAdapter(uadap);

        getData();

        uadap = new Adapter(getContext(), dataClassArrayList,this);
        listSeller.setAdapter(uadap);
        uadap.notifyDataSetChanged();
        return v;
    }



    @Override
    public void onResume() {
        getData();
        super.onResume();
    }

    private void getData() {
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dataClassArrayList.clear();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    jsonArray = jsonObject.getJSONArray("data");
                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String name = object.getString("CName");
                            String img = object.getString("imageUrl");
                            Picasso.get()
                                    .load(img)
                                    .into(new Target() {
                                        @Override
                                        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                            bitmp = bitmap;

                                        }

                                        @Override
                                        public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                                        }

                                        @Override
                                        public void onPrepareLoad(Drawable placeHolderDrawable) {

                                        }
                                    });

                            uDataClass = new UDataClass(name, bitmp);
                            dataClassArrayList.add(uDataClass);
                            uadap.notifyDataSetChanged();
                        }
                    }


                } catch (Exception e) {
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }

        });
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }

    @Override
    public void onclick(int position) {
        Bundle bundle = new Bundle();
        JSONObject object = null;
        try {
            object = jsonArray.getJSONObject(position);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        try {
            did = object.getString("UserID");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        bundle.putString("id", did);


        Fragment fragment = new ProductsFilterFragment();
        fragment.setArguments(bundle);

        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }

    }
}