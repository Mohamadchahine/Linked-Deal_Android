package com.ChahineCodiTech.linkeddeal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OItemAdapter extends RecyclerView.Adapter<OItemAdapter.RCViewHolder>{

    Context context;
    ArrayList<OItemCode> modelArrayList;

    private final ShopListInterface shopListInterface;

    public OItemAdapter(Context context, ArrayList<OItemCode> modelArrayList,ShopListInterface shopListInterface) {
        this.context = context;
        this.modelArrayList = modelArrayList;
        this.shopListInterface=shopListInterface;
    }

    @NonNull
    @Override
    public OItemAdapter.RCViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.ordreditemslist, parent, false);
        return new OItemAdapter.RCViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OItemAdapter.RCViewHolder holder, int position) {
        OItemCode model = modelArrayList.get(position);

        holder.image.setImageBitmap(model.img);

        holder.ID.setText("#:"+model.ID);
        holder.Name.setText(model.Name);
        holder.qty.setText("quantity: "+model.Quantity);
        holder.total.setText("Total: "+model.Total+"$");
    }

    @Override
    public int getItemCount() {
        return modelArrayList.size();
    }

    public class RCViewHolder extends RecyclerView.ViewHolder{

        TextView ID,Name,qty,total;
        ImageView image;

        public RCViewHolder(@NonNull View itemView) {
            super(itemView);

            image=itemView.findViewById(R.id.itemimg);
            ID = itemView.findViewById(R.id.itemid);
            Name = itemView.findViewById(R.id.itemname);
            qty = itemView.findViewById(R.id.itemqnty);
            total = itemView.findViewById(R.id.itemtotal);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(shopListInterface != null){
                        int pos = getAdapterPosition();

                        shopListInterface.onclick(pos);
                    }
                }
            });


        }
    }
}
