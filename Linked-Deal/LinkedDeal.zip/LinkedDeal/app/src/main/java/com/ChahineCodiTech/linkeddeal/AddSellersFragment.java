package com.ChahineCodiTech.linkeddeal;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


public class AddSellersFragment extends Fragment {


    EditText id, pass, conpass;
    Button add;

    String url = "https://linkeddeal.000webhostapp.com/Scripts/AddUsers.php";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_add_sellers, container, false);

        add = v.findViewById(R.id.add1);
        id = v.findViewById(R.id.addUserID);
        pass = v.findViewById(R.id.addUserPassword);
        conpass = v.findViewById(R.id.confUserPassword);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (id.getText().toString().isEmpty() || pass.getText().toString().isEmpty() || conpass.getText().toString().isEmpty()) {
                    Toast.makeText(getContext(), "Please Fill All Fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass.getText().toString().equals(conpass.getText().toString())) {

                        String Uid = id.getText().toString();
                        String Upass = conpass.getText().toString();

                        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                id.setText("");
                                pass.setText("");
                                conpass.setText("");
                                Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }) {
                            @Nullable
                            @Override
                            protected Map<String, String> getParams() throws AuthFailureError {
                                Map<String, String> parms = new HashMap<String, String>();

                                parms.put("UserID", Uid);
                                parms.put("Password", Upass);

                                return parms;
                            }
                        };
                        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
                        requestQueue.add(request);
                    } else {
                        Toast.makeText(getContext(), "Password Doesnt match!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        return v;
    }
}