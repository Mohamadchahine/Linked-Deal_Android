package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class OrderdonedetailsFragment extends Fragment implements ShopListInterface{

    Bundle bundle;
    String OID;
    String get="https://linkeddeal.000webhostapp.com/Scripts/getOrders.php"
            ,url="https://linkeddeal.000webhostapp.com/Scripts/getorderlist.php";

    TextView OrderID,CName,CAdress,CPhone,CNotes,CDate;
    String sCName,sCAdress,sCPhone,sCNotes,sCDate;

    RecyclerView recyclerView;
    ArrayList<OItemCode> modelArrayList;
    OItemAdapter adapt;
    OItemCode Prod;

    Bitmap bitmp;
    LinearLayoutManager linearLayoutManager;
    JSONArray jsonArray;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_orderdonedetails, container, false);

        bundle = getArguments();
        OID = bundle.getString("OID", "x");

        OrderID = v.findViewById(R.id.dText_orderid);
        CName = v.findViewById(R.id.dCustomerName);
        CPhone = v.findViewById(R.id.dCustomerPhone);
        CAdress = v.findViewById(R.id.dCustomerAdress);
        CNotes = v.findViewById(R.id.dCustomerNotes);
        CDate = v.findViewById(R.id.dDate);





        recyclerView=v.findViewById(R.id.proddonelistadmin);


        recyclerView.setHasFixedSize(true);

        modelArrayList = new ArrayList<>();
        adapt = new OItemAdapter(getContext(), modelArrayList,this);

        //make 2 in each row
        linearLayoutManager = new GridLayoutManager(getActivity(), 1); // Set span count to 1
        recyclerView.setLayoutManager(linearLayoutManager);


        recyclerView.setAdapter(adapt);


        getData();
        getList();

        adapt = new OItemAdapter(getContext(), modelArrayList,this);
        recyclerView.setAdapter(adapt);
        adapt.notifyDataSetChanged();




        return v;
    }

    private void getList() {

        url += "?OID="+OID;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                modelArrayList.clear();

                try {
                    // No need to create a JSONObject since we're getting a JSONArray response
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject object = response.getJSONObject(i);
                        String Quantity = object.getString("qty");
                        String Total = object.getString("TotalPrice");
                        String Img = object.getString("imageUrl");
                        String PID = object.getString("PID");
                        String PName = object.getString("PName");

                        // Load image using Glide instead of Picasso
                        Glide.with(getContext())
                                .load(Img)
                                .into(new CustomTarget<Drawable>() {
                                    @Override
                                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                                        // Create a new OItemCode object with the loaded image
                                        Prod = new OItemCode(PID, PName, Total, Quantity, ((BitmapDrawable) resource).getBitmap());
                                        modelArrayList.add(Prod);
                                        adapt.notifyDataSetChanged();
                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {
                                    }
                                });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getContext(), "Error parsing JSON response", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(getContext(), "Error retrieving data", Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }


    @Override
    public void onResume() {
        getData();
        getList();
        super.onResume();
    }

    private void getData() {
        get+="?OID="+OID;
        JsonArrayRequest request = new JsonArrayRequest( get, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject jsonObject = response.getJSONObject(0);
                    sCName = jsonObject.getString("FullName");
                    sCAdress = jsonObject.getString("CAddress");
                    sCPhone = jsonObject.getString("PhoneNb");
                    sCNotes = jsonObject.getString("Notes");
                    sCDate=jsonObject.getString("Date");
                    CDate.setText("Date: "+sCDate);

                    OrderID.setText("OrderId: #"+OID);
                    CName.setText("Name: "+sCName);
                    CPhone.setText("Phone: "+sCPhone);
                    CAdress.setText("Address: "+sCAdress);
                    CNotes.setText("Notes: "+sCNotes);


                } catch (Exception e) {
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }

        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("OID", OID);

                return parms;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }

    @Override
    public void onclick(int position) {

    }
}