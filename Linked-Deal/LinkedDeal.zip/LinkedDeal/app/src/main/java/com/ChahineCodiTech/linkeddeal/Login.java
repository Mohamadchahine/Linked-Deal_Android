package com.ChahineCodiTech.linkeddeal;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    String UserID, Password;
    EditText id, pass;

    String url = "https://linkeddeal.000webhostapp.com/Scripts/LogIn.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        id = findViewById(R.id.ID);
        pass = findViewById(R.id.Password);

    }

    public  void login(View v){
        UserID = id.getText().toString();
        Password = pass.getText().toString();

        if(isValid(UserID, Password)){
            SignIn(UserID, Password);
        }
    }

    private Boolean isValid(String UserID, String Password){
        if(UserID.isEmpty() || Password.isEmpty()){
            Toast.makeText(this, "Fill All Fields", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }


    private void SignIn(final String UserID, final String Password) {
        StringRequest request= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equals("success, Seller")) {

                    Intent i = new Intent(Login.this, SellerDashboard.class);
                    id.setText("");
                    pass.setText("");
                    i.putExtra("UserID",UserID);
                    startActivity(i);
                } else if (response.equals("success, Admin")) {

                    Intent j = new Intent(Login.this, admin_dashboard.class);
                    id.setText("");
                    pass.setText("");
                    j.putExtra("UserID",UserID);
                    startActivity(j);
                } else {
                    Toast.makeText(Login.this, "Authorized Users Only!!!", Toast.LENGTH_LONG).show();
                    id.setText("");
                    pass.setText("");
                }
            }
        },new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Login.this, error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }){
            @Nullable
            @Override

            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<>();

                parms.put("UserID", UserID);
                parms.put("Password", Password);
                return parms;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Login.this);
        requestQueue.add(request);


    }
}