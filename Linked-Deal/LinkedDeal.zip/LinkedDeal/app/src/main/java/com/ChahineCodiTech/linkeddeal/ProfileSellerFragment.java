package com.ChahineCodiTech.linkeddeal;

import static android.app.Activity.RESULT_OK;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;


public class ProfileSellerFragment extends Fragment {


    TextView name,email,phone;
    EditText ename,eemail,ephone;
    String uename,ueemail,uephone;
    String gname, gemail, gphone ,UserID ,imageUrl;

    String list ="https://linkeddeal.000webhostapp.com/Scripts/ProfileViewSeller.php";
    String update="https://linkeddeal.000webhostapp.com/Scripts/SelerProfileEdit.php";
    Button btnupdate;
    ImageView img;
    Uri selecteduri;
    Bitmap bitmp;
    String encodeImage;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_profile_seller, container, false);
        name=v.findViewById(R.id.CName);
        email=v.findViewById(R.id.CEmail);
        phone=v.findViewById(R.id.CPhone);
        img = v.findViewById(R.id.profilelogo);

        ename=v.findViewById(R.id.ECName);
        eemail=v.findViewById(R.id.ECEmail);
        ephone=v.findViewById(R.id.ECPhone);

        UserID = SellerDashboard.getUserID();

        btnupdate = v.findViewById(R.id.ProfileEditDone);

        ProfileView();

        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    UpdateProfile();
                }catch (Exception e){
                    Toast.makeText(getContext(), "Please enter A new Image and fill All Fields", Toast.LENGTH_SHORT).show();
                }

            }
        });

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChooseImage();
            }
        });



        return v;
    }




    private void UpdateProfile() {
        if (ename.getText().toString().isEmpty() || eemail.getText().toString().isEmpty() || ephone.getText().toString().isEmpty() || selecteduri == null) {
            Toast.makeText(getContext(), "Please Fill All Fields & Select Image", Toast.LENGTH_SHORT).show();
        } else {
            uename = ename.getText().toString();
            ueemail = eemail.getText().toString();
            uephone = ephone.getText().toString();

            update+="?UserID="+UserID;
            StringRequest request = new StringRequest(Request.Method.POST, update, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    ename.setText("");
                    eemail.setText("");
                    ephone.setText("");
                    Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();

                    name.setText("Shop Name: "+uename);
                    email.setText("E-mail: "+ueemail);
                    phone.setText("Phone: "+uephone);


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("CName", uename);
                    parms.put("Email", ueemail);
                    parms.put("Phonenb", uephone);
                    parms.put("Logo",encodeImage);

                    return parms;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            requestQueue.add(request);
        }
    }

    private void ProfileView() {
        list+="?UserID="+UserID;
        JsonArrayRequest request = new JsonArrayRequest( list, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try{
                    JSONObject jsonObject = response.getJSONObject(0);
                    gname=jsonObject.getString("CName");
                    gemail=jsonObject.getString("Email");
                    gphone=jsonObject.getString("Phonenb");



                    name.setText("Shop Name: "+gname);
                    email.setText("E-mail: "+gemail);
                    phone.setText("Phone: "+gphone);

                    imageUrl = jsonObject.getString("imageUrl");



                    Picasso.get().load(imageUrl).into(img);
                    //in this example, the Picasso.get().load(imageUrl).into(img) code loads the image from the URL imageUrl and displays it in the img ImageView.

                }catch (Exception e){
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("UserID", UserID);

                return parms;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }


    //Image
    private void ChooseImage() {
        ImagePicker.with(this)
                .cropSquare()	    			//Crop image(Optional), Check Customization for more option
                .compress(1024)			//Final image size will be less than 1 MB(Optional)
                .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                .start();
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && data != null) {
            selecteduri = data.getData();
            try {
                InputStream inputStream = requireContext().getContentResolver().openInputStream(selecteduri);
                bitmp = BitmapFactory.decodeStream(inputStream);
                img.setImageURI(selecteduri);
                ImageStore(bitmp);

                // You now have the bitmap and the encoded string
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void ImageStore(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte [] imagebyte = stream.toByteArray();
        encodeImage = android.util.Base64.encodeToString(imagebyte, Base64.DEFAULT);
    }
}