package com.ChahineCodiTech.linkeddeal;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;


public class FavFragment extends Fragment implements ShopListInterface{


    OItemAdapter adapt;
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;

    Button clearbtn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_fav, container, false);
        recyclerView=v.findViewById(R.id.prodlistfav);
        clearbtn = v.findViewById(R.id.clearbtn);

        recyclerView.setHasFixedSize(true);


        adapt = new OItemAdapter(getContext(), FavArray.getProducts(),this);
        linearLayoutManager = new GridLayoutManager(getActivity(), 1); // Set span count to 1
        recyclerView.setLayoutManager(linearLayoutManager);


        recyclerView.setAdapter(adapt);

        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FavArray.clearProducts();
                adapt.notifyDataSetChanged();
            }
        });

        return v;
    }

    @Override
    public void onclick(int position) {
        String quantity = FavArray.getProducts().get(position).getQuantity();
        String PID = FavArray.getProducts().get(position).getID();
        Fragment fragment = new ItemDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putString("quant",quantity);
        bundle.putString("PID",PID);

        fragment.setArguments(bundle);
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }
    }
}