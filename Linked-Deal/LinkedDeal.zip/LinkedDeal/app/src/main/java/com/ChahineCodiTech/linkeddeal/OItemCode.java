package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;

public class OItemCode {

    String ID,Name,Total,Quantity,Seller;
    Bitmap img;

    public OItemCode(String ID, String name, String total, String quantity, Bitmap img,String Seller) {
        this.ID = ID;
        Name = name;
        Total = total;
        Quantity = quantity;
        this.img = img;
        this.Seller=Seller;
    }

    public OItemCode(String ID, String name, String total, String quantity, Bitmap img) {
        this.ID = ID;
        Name = name;
        Total = total;
        Quantity = quantity;
        this.img = img;

    }

    public String getSeller() {
        return Seller;
    }

    public void setSeller(String seller) {
        Seller = seller;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        Total = total;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        Quantity = quantity;
    }

    public Bitmap getImg() {
        return img;
    }

    public void setImg(Bitmap img) {
        this.img = img;
    }
}
