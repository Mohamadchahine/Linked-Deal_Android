package com.ChahineCodiTech.linkeddeal;

public class CategoriesCode {
    String CategoryName;

    public CategoriesCode(String categoryName) {
        CategoryName = categoryName;
    }

    public String getCategoryName() {
        return CategoryName;
    }

    public void setCategoryName(String categoryName) {
        CategoryName = categoryName;
    }
}
