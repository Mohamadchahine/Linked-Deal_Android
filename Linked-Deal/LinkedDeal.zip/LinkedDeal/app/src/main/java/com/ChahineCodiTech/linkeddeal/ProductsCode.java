package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;

public class ProductsCode {
    String PName;
    String PPrice;
    Bitmap Img;

    public ProductsCode(String PName, String PPrice, Bitmap img) {
        this.PName = PName;
        this.PPrice = PPrice + "$";
        Img = img;
    }

    public String getPName() {
        return PName;
    }

    public void setPName(String PName) {
        this.PName = PName;
    }

    public String getPPrice() {
        return PPrice;
    }

    public void setPPrice(String PPrice) {
        this.PPrice = PPrice;
    }

    public Bitmap getImg() {
        return Img;
    }

    public void setImg(Bitmap img) {
        Img = img;
    }
}
