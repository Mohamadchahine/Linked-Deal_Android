package com.ChahineCodiTech.linkeddeal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.RCViewHolder>{

    Context context;
    ArrayList<CategoriesCode> modelArrayList;

    private final ShopListInterface shopListInterface;


    public CategoriesAdapter(Context context, ArrayList<CategoriesCode> modelArrayList,ShopListInterface shopListInterface) {
        this.context = context;
        this.modelArrayList = modelArrayList;
        this.shopListInterface=shopListInterface;
    }

    @NonNull
    @Override
    public CategoriesAdapter.RCViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.categorylist, parent, false);
        return new CategoriesAdapter.RCViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoriesAdapter.RCViewHolder holder, int position) {
        CategoriesCode model = modelArrayList.get(position);

        holder.CategoryName.setText(model.CategoryName);
    }

    @Override
    public int getItemCount() {
        return modelArrayList.size();
    }

    public class RCViewHolder extends RecyclerView.ViewHolder{

        TextView CategoryName;

        public RCViewHolder(@NonNull View itemView) {
            super(itemView);

            CategoryName = itemView.findViewById(R.id.CategoryName);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(shopListInterface != null){
                        int pos = getAdapterPosition();

                        shopListInterface.onclick(pos);
                    }
                }
            });


        }
    }
}
