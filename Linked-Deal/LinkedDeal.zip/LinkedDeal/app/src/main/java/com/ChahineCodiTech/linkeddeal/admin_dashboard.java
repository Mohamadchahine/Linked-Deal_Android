package com.ChahineCodiTech.linkeddeal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class admin_dashboard extends AppCompatActivity {

    BottomNavigationView b;

    String UserID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);


        if(savedInstanceState ==null){
            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout,new ViewSellersFragment()).commit();

        }
        Intent x = getIntent();
        UserID= x.getStringExtra("UserID");

        //bottom menu
        b=findViewById(R.id.bottomAdminView);
        b.setBackground(null);
        b.setOnItemSelectedListener(item -> {

            switch (item.getItemId()) {
                case R.id.sellers:
                    replaceFragment(new ViewSellersFragment());
                    break;
                case R.id.add:
                    replaceFragment(new AddSellersFragment());
                    break;


                case R.id.Logout:

                    this.finish();
                    break;


            }
            return true;
        });
    }

    private  void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }

}