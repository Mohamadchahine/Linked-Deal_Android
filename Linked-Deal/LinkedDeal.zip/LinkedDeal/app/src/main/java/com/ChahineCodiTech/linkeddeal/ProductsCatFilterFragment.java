package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class ProductsCatFilterFragment extends Fragment implements ShopListInterface{

    String CatID,PID;
    String url="https://linkeddeal.000webhostapp.com/Scripts/ViewProductsCat.php";

    RecyclerView recyclerView;
    ArrayList<ProductsCode> modelArrayList;
    ProductsAdapter adapt;
    ProductsCode Prod;

    Bitmap bitmp;
    LinearLayoutManager linearLayoutManager;
    Bundle bundle;
    JSONArray jsonArray;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_products_cat_filter, container, false);
        Bundle bundle = getArguments();
        CatID = bundle.getString("CatID", "x");



        recyclerView=v.findViewById(R.id.prodlistcatguest);



        recyclerView.setHasFixedSize(true);

        modelArrayList = new ArrayList<>();
        adapt = new ProductsAdapter(getContext(), modelArrayList,this);

        //make 2 in each row
        linearLayoutManager = new GridLayoutManager(getActivity(), 2); // Set span count to 2
        recyclerView.setLayoutManager(linearLayoutManager);


        recyclerView.setAdapter(adapt);


        getData();
        // Update the adapter and notifyDataSetChanged() method
        adapt = new ProductsAdapter(getContext(), modelArrayList,this);
        recyclerView.setAdapter(adapt);
        adapt.notifyDataSetChanged();

        return v;
    }

    private void getData() {
        url+="?Category_ID="+CatID;
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                modelArrayList.clear();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    jsonArray = jsonObject.getJSONArray("data");
                    if (success.equals("1")){
                        for(int i=0; i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            String PName = object.getString("PName");
                            String PPrice = object.getString("Price");
                            String Img = object.getString("imageUrl");


                            Picasso.get()
                                    .load(Img)
                                    .into(new Target() {
                                        @Override
                                        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                            bitmp = bitmap;

                                        }

                                        @Override
                                        public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                                        }

                                        @Override
                                        public void onPrepareLoad(Drawable placeHolderDrawable) {

                                        }
                                    });

                            Prod = new ProductsCode(PName,PPrice,bitmp);
                            modelArrayList.add(Prod);
                            adapt.notifyDataSetChanged();
                        }
                    }

                }catch (Exception e){
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();

            }

        });
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }


    @Override
    public void onclick(int position) {

        Fragment fragment = new ItemDetailsFragment();
        JSONObject object = null;
        try {
            object = jsonArray.getJSONObject(position);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        try {
            PID = object.getString("PID");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        bundle=new Bundle();
        bundle.putString("PID",PID);
        fragment.setArguments(bundle);

        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }

    }
}
