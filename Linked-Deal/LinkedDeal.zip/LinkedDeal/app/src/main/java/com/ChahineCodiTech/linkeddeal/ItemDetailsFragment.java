package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class ItemDetailsFragment extends Fragment {

    String url="https://linkeddeal.000webhostapp.com/Scripts/ViewProductsdetails.php";

    TextView name,description,price,company,avqty;
    EditText quantity;
    Bundle bundle;

    String PName,PPrice,PDesc,PShop,PID,imageUrl,Total,Quantity,Seller,pqty,sentquan;
    ImageView img;
    Bitmap bitimg;
    ImageButton fav;

    Button buy;
    OItemCode Prod;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_item_details, container, false);
        name = v.findViewById(R.id.Product_Name);
        description = v.findViewById(R.id.Product_Description);
        price = v.findViewById(R.id.Product_Price);
        company = v.findViewById(R.id.Seller_Shop);
        img=v.findViewById(R.id.Product_Image);
        bundle = getArguments();
        PID = bundle.getString("PID", "x");
        sentquan = bundle.getString("quant","1");
        quantity = v.findViewById(R.id.Product_Quantity);
        quantity.setText(sentquan);
        fav=v.findViewById(R.id.FavButton);
        buy = v.findViewById(R.id.Buy);
        avqty=v.findViewById(R.id.pqty);
        getData();


        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToFav();
            }
        });
        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Quantity=quantity.getText().toString();
                int quan=Integer.parseInt(Quantity);
                int q = Integer.parseInt(pqty);
                if(quan <= q){
                    BuyNow();
                }else {
                    Toast.makeText(getContext(), "We Dont have this Quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });


        return v;
    }

    /*
    @Override
    public void onStart() {
        getData();
        super.onStart();
    }*/

    @Override
    public void onResume() {
        getData();
        super.onResume();
    }

    private void BuyNow() {
        AddItem();
        Fragment fragment = new CheckOutFragment();
        FragmentManager fragmentManager = getFragmentManager();
        if (fragmentManager != null) {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }
    }

    private void AddItem() {
        Quantity=quantity.getText().toString();
        int price = Integer.parseInt(PPrice);
        int quan=Integer.parseInt(Quantity);
        int tot=price*quan;
        Total=String.valueOf(tot);
        bitimg=((BitmapDrawable)img.getDrawable()).getBitmap();
        Prod = new OItemCode(PID, PName, Total, Quantity, bitimg,Seller);
        ProdArray.addProduct(Prod);
    }


    private void addToFav() {
        Quantity=quantity.getText().toString();
        int price = Integer.parseInt(PPrice);
        int quan=Integer.parseInt(Quantity);
        int tot=price*quan;
        Total=String.valueOf(tot);
        bitimg=((BitmapDrawable)img.getDrawable()).getBitmap();
        Prod = new OItemCode(PID, PName, Total, Quantity, bitimg,Seller);
        FavArray.addProduct(Prod);
        Toast.makeText(getContext(), "Added to favorites", Toast.LENGTH_SHORT).show();
    }

    private void getData() {
        url += "?PID="+PID;
        JsonArrayRequest request = new JsonArrayRequest( url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject jsonObject = response.getJSONObject(0);
                    PName = jsonObject.getString("PName");
                    PPrice = jsonObject.getString("Price");
                    PShop = jsonObject.getString("CName");
                    PDesc = jsonObject.getString("Description");
                    Seller = jsonObject.getString("SellerID");
                    pqty=jsonObject.getString("Quantity");

                    if(Integer.parseInt(pqty)<=0){
                        buy.setEnabled(false);
                        Toast.makeText(getContext(), "Sorry, Out of Stock", Toast.LENGTH_SHORT).show();
                    }

                    name.setText(PName);
                    price.setText(PPrice+"$");
                    company.setText(PShop);
                    description.setText(PDesc);
                    avqty.setText("Available: "+ pqty);

                    imageUrl = jsonObject.getString("imageUrl");
                    Picasso.get().load(imageUrl).into(img);
                } catch (Exception e) {
                    Toast.makeText(getContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parms = new HashMap<String, String>();

                parms.put("PID", PID);

                return parms;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(request);
    }
}