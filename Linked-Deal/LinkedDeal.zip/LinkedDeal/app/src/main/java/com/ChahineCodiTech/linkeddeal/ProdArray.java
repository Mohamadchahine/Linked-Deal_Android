package com.ChahineCodiTech.linkeddeal;

import java.util.ArrayList;

public class ProdArray {

    private static ArrayList<OItemCode> products= new ArrayList<>(); // Declare the ArrayList to hold the products

    public ProdArray() {
        products = new ArrayList<OItemCode>(); // Initialize the ArrayList in the constructor
    }

    // Add a method to add a product to the array
    public static void addProduct(OItemCode product) {
        products.add(product);
    }

    // Add a method to remove a product from the array
    public static void removeProduct(OItemCode product) {
        products.remove(product);
    }

    // Add a method to get the products in the array
    public static ArrayList<OItemCode> getProducts() {
        return products;
    }

    public static void clearProducts() {
        products.clear();
    }
}
