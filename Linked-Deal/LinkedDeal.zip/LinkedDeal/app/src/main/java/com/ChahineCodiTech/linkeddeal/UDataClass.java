package com.ChahineCodiTech.linkeddeal;

import android.graphics.Bitmap;

public class UDataClass {

    String UserID, CName, Email, Phonenb;
    Bitmap bitmap ;

    public UDataClass(String userID, String CName, String email, String phonenb) {
        UserID = userID;
        this.CName = CName;
        Email = email;
        Phonenb = phonenb;
    }

    public UDataClass( String CName, Bitmap bitmap) {
        this.CName = CName;
        this.bitmap = bitmap;
    }



    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getCName() {
        return CName;
    }

    public void setCName(String CName) {
        this.CName = CName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhonenb() {
        return Phonenb;
    }

    public void setPhonenb(String phonenb) {
        Phonenb = phonenb;
    }

    public Bitmap getbitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }




}
