package com.ChahineCodiTech.linkeddeal;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.dhaval2404.imagepicker.ImagePicker;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;


public class SellerAddProductsFragment extends Fragment {

    ImageView productimg;
    EditText prodname, prodprice, prodquantity, prodDesc;
    String sprodname, sprodprice, sprodquantity, sprodDesc, scat,catID;
    Spinner prodCat;
    Button addproduct;

    Uri selecteduri;
    Bitmap bitmp;
    String encodeImage,UserID;

    String url="https://linkeddeal.000webhostapp.com/Scripts/AddProducts.php";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_seller_add_products, container, false);

        UserID = SellerDashboard.getUserID();


        productimg = v.findViewById(R.id.Productimgup);
        prodname = v.findViewById(R.id.Productnameup);
        prodprice = v.findViewById(R.id.Productpriceup);
        prodquantity = v.findViewById(R.id.Productquantityup);
        prodDesc = v.findViewById(R.id.Productdescup);
        prodCat = v.findViewById(R.id.Productcatup);
        addproduct = v.findViewById(R.id.addproductsbtn);

        productimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChooseImage();
            }
        });

        addproduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddProduct();
            }
        });




        return v;
    }

    private void AddProduct() {

        if (prodname.getText().toString().isEmpty() || prodprice.getText().toString().isEmpty() ||
                prodquantity.getText().toString().isEmpty() || prodDesc.getText().toString().isEmpty() ||selecteduri == null) {
            Toast.makeText(getContext(), "Please Fill All Fields & Select Image", Toast.LENGTH_SHORT).show();
        } else {
            sprodname = prodname.getText().toString();
            sprodprice = prodprice.getText().toString();
            sprodquantity = prodquantity.getText().toString();
            sprodDesc = prodDesc.getText().toString();

            scat = String.valueOf(prodCat.getSelectedItem());

            url+="?UserID="+UserID;
            StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    prodname.setText("");
                    prodprice.setText("");
                    prodquantity.setText("");
                    prodDesc.setText("");
                    Toast.makeText(getContext(), response, Toast.LENGTH_SHORT).show();
                    Fragment fragment = new SellerProductsFragment();
                    FragmentManager fragmentManager = getFragmentManager();
                    if (fragmentManager != null) {
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.frame_layout, fragment);
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.commit();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> parms = new HashMap<String, String>();

                    parms.put("PName", sprodname);
                    parms.put("Category", String.valueOf(scat.charAt(0)));
                    parms.put("Description", sprodDesc);
                    parms.put("Quantity", sprodquantity);
                    parms.put("Price", sprodprice);
                    parms.put("Image",encodeImage);

                    return parms;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            requestQueue.add(request);
        }

    }



    private void ChooseImage() {
        ImagePicker.with(this)
                .cropSquare()	    			//Crop image(Optional), Check Customization for more option
                .compress(1024)			//Final image size will be less than 1 MB(Optional)
                .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                .start();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && data != null) {
            selecteduri = data.getData();
            try {
                InputStream inputStream = requireContext().getContentResolver().openInputStream(selecteduri);
                bitmp = BitmapFactory.decodeStream(inputStream);
                productimg.setImageURI(selecteduri);
                ImageStore(bitmp);

                // You now have the bitmap and the encoded string
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void ImageStore(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
        byte [] imagebyte = stream.toByteArray();
        encodeImage = android.util.Base64.encodeToString(imagebyte, Base64.DEFAULT);
    }
}