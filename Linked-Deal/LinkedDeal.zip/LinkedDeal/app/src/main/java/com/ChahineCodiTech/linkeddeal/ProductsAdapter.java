package com.ChahineCodiTech.linkeddeal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProductsAdapter  extends RecyclerView.Adapter<ProductsAdapter.RCViewHolder>{
    Context context;
    ArrayList<ProductsCode> modelArrayList;
    private final ShopListInterface shopListInterface;


    public ProductsAdapter(Context context, ArrayList<ProductsCode> modelArrayList,ShopListInterface shopListInterface) {
        this.context = context;
        this.modelArrayList = modelArrayList;
        this.shopListInterface=shopListInterface;
    }

    @NonNull
    @Override
    public RCViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.productlistv_card, parent, false);
        return new RCViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RCViewHolder holder, int position) {
        ProductsCode model = modelArrayList.get(position);
        holder.image.setImageBitmap(model.Img);
        holder.name.setText(model.PName);
        holder.price.setText(model.PPrice);
    }

    @Override
    public int getItemCount() {
        return modelArrayList.size();
    }

    public class RCViewHolder extends RecyclerView.ViewHolder{

        ImageView image;
        TextView price, name;

        public RCViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.itemimg);
            price = itemView.findViewById(R.id.price);
            name = itemView.findViewById(R.id.name);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(shopListInterface != null){
                        int pos = getAdapterPosition();

                        shopListInterface.onclick(pos);
                    }
                }
            });

        }
    }
}
