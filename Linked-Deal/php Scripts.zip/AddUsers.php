<?php
$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

$UserID = $_POST["UserID"];
$Password = $_POST["Password"];



$sql = "INSERT INTO USERS(UserID, Password) VALUES ('$UserID', '$Password')";

$result = mysqli_query($con, $sql);

if($result){
	echo "Inserted Successfully";
}else{
	echo "Error occured";
}

?>