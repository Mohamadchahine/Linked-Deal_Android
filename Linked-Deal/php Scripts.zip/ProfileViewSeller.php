<?php

    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");



	
	$UserID = strip_tags(addslashes($_GET['UserID']));


	$select = "SELECT * FROM USERS WHERE UserType = 'Seller' AND UserID = '$UserID'";
	$response = mysqli_query($con, $select);
	if($response){
	    $result = array();
	    while($row =mysqli_fetch_assoc($response)){
	    	$imageFilePath = $row['Logo']; // Replace 'image_field_name' with the actual field name that stores the image file path in the database

            // Concatenate image file path with folder path to generate URL
            $imageUrl = 'https://linkeddeal.000webhostapp.com/Scripts/imageLogo/' . $imageFilePath; // Replace 'https://example.com' with the base URL of your website and 'images' with the actual folder name where the images are stored

            $row['imageUrl'] = $imageUrl;

            $result[] = $row;
        }
	    
	    echo json_encode($result);
	
    	mysqli_free_result($response);
    	mysqli_close($con);
	}

	
	



?>