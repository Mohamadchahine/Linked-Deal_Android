<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $OID = strip_tags(addslashes($_GET['OID']));

	$result = array();
	$result['data']=array();

	$select = "SELECT * FROM Orders WHERE OID='$OID'";

	$response = mysqli_query($con, $select);


	if($response){
		    $result = array();
		    while($row =mysqli_fetch_assoc($response)){
		    	

	            $result[] = $row;
	        }
		    
		    echo json_encode($result);
		
	    	mysqli_free_result($response);
	    	mysqli_close($con);
		}


?>