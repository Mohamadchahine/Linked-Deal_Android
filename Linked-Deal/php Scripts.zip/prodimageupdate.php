<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $UserID = strip_tags(addslashes($_GET['UserID']));
    $PID = strip_tags(addslashes($_GET['PID']));




	$Image = $_POST['Image'];
	 $targetdir = "imageProd/";

	$imagestore = rand()."_".time().".jpeg";
	$targetdir = $targetdir."/".$imagestore;

 	file_put_contents($targetdir,base64_decode($Image));

	$query="UPDATE Products SET Image='$imagestore' WHERE SellerID='$UserID'&& PID='$PID' ";

	$result=mysqli_query($con,$query);

	if($result){
		echo "Update Done!";
	}else{
		echo "Failed";
	}

	mysqli_close($con);
?>