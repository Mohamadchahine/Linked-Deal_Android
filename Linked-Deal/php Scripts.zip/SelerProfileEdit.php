<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $UserID = strip_tags(addslashes($_GET['UserID']));
	$CName = $_POST['CName'];
	$Email = $_POST['Email'];
	$Phonenb = $_POST['Phonenb'];

	$Logo = $_POST['Logo'];
	 $targetdir = "imageLogo/";

	$imagestore = rand()."_".time().".jpeg";
	$targetdir = $targetdir."/".$imagestore;

 	file_put_contents($targetdir,base64_decode($Logo));

	$query="UPDATE USERS SET CName='$CName',Email='$Email',Phonenb='$Phonenb',Logo='$imagestore' WHERE UserID='$UserID' ";

	$result=mysqli_query($con,$query);

	if($result){
		echo "Update Done!";
	}else{
		echo "Failed";
	}

	mysqli_close($con);
?>