<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $OID = strip_tags(addslashes($_GET['OID']));

	$result = array();
	$result['data']=array();

	$select = "SELECT * FROM OrderItems
                    JOIN Products ON CAST(OrderItems.PID AS INT) = CAST(Products.PID AS INT)
                        WHERE OID='$OID'";

	$response = mysqli_query($con, $select);


	if($response){
		    $result = array();
		    while($row =mysqli_fetch_assoc($response)){
		    	$imageFilePath = $row['Image']; // Replace 'image_field_name' with the actual field name that stores the image file path in the database

	            // Concatenate image file path with folder path to generate URL
	            $imageUrl = 'https://linkeddeal.000webhostapp.com/Scripts/imageProd/' . $imageFilePath; // Replace 'https://example.com' with the base URL of your website and 'images' with the actual folder name where the images are stored

	            $row['imageUrl'] = $imageUrl;
	           $result[] = $row;
	        }
		    
		    echo json_encode($result);
		
	    	mysqli_free_result($response);
	    	mysqli_close($con);
		}


?>