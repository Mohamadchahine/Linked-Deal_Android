<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

	$PID = $_POST['PID'];
	$query = "DELETE FROM Products WHERE PID = '$PID'";

	$result = mysqli_query($con, $query);

	if($result){
		echo "Deleted Products!";
	}else{
		echo "Failed!";
	}

	mysqli_close($con);
?>