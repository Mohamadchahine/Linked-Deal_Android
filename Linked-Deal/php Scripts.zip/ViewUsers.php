<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

	$result = array();
	$result['data']=array();

	$select = "SELECT * FROM USERS WHERE UserType = 'Seller'";

	$response = mysqli_query($con, $select);

	while($row = mysqli_fetch_array($response)){
		$index['UserID'] = $row['1'];
		$index['CName'] = $row['2'];
		
		$index['Email'] = $row['6'];
		$index['Phonenb'] = $row['7'];
		
		
		$imageFilePath = $row['Logo']; 

        $imageUrl = 'https://linkeddeal.000webhostapp.com/Scripts/imageLogo/' . $imageFilePath; 
        $row['imageUrl'] = $imageUrl;
        $index['imageUrl']=$imageUrl;

		array_push($result['data'], $index);
	}

	$result["success"]="1";
	echo json_encode($result);
	mysqli_close($con);

?>