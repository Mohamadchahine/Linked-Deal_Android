<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");


	$result = array();
	$result['data']=array();

	$select = "SELECT * FROM Category";

	$response = mysqli_query($con, $select);

	while($row = mysqli_fetch_array($response)){
	   	$index['Category_ID']= $row['0'];
		$index['Category_Name'] = $row['1'];

		array_push($result['data'], $index);
	}

	$result["success"]="1";
	echo json_encode($result);

	mysqli_close($con);
?>