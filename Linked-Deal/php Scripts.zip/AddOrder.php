<?php
    $con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $UserID = strip_tags(addslashes($_GET['UserID']));
    $Name = $_POST['Name'];
	$Phone = $_POST['Phone'];
	$Address = $_POST['Address'];
	$Note = $_POST['Note'];

	$select = "INSERT INTO `Orders`( `SellerID`, `FullName`, `PhoneNb`, `CAddress`, `Notes`) VALUES ('$UserID','$Name','$Phone','$Address','$Note')";

    $result=mysqli_query($con,$select);

	if($result){
		echo 'OrderCompleted!';
	}else{
		echo 'failed';
	}

	mysqli_close($con);
	
?>
