<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $UserID = strip_tags(addslashes($_GET['UserID']));
    $PID = strip_tags(addslashes($_GET['PID']));


	$PName = $_POST['PName'];
	$Description = $_POST['Description'];
	$Quantity = $_POST['Quantity'];
	$Price = $_POST['Quantity'];


	$query="UPDATE Products SET PName='$PName',Description='$Description',Quantity='$Quantity',Price='$Price' WHERE SellerID='$UserID'&& PID='$PID' ";

	$result=mysqli_query($con,$query);

	if($result){
		echo "Update Done!";
	}else{
		echo "Failed";
	}

	mysqli_close($con);
?>