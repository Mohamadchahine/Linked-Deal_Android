<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $UserID = strip_tags(addslashes($_GET['UserID']));

	$result = array();
	$result['data']=array();

	$select = "SELECT * FROM Products WHERE SellerID = '$UserID'";

	$response = mysqli_query($con, $select);

	while($row = mysqli_fetch_array($response)){
		$index ['PID'] = $row['0'];
		$index['PName'] = $row['1'];
		$index['Price'] = $row['6'];
		
		
		
		$imageFilePath = $row['Image']; 

        $imageUrl = 'https://linkeddeal.000webhostapp.com/Scripts/imageProd/' . $imageFilePath; 
        $row['imageUrl'] = $imageUrl;
        $index['imageUrl']=$imageUrl;

		array_push($result['data'], $index);
	}

	$result["success"]="1";
	echo json_encode($result);

	mysqli_close($con);
?>