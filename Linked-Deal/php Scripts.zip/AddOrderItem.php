<?php
$con = mysqli_connect("localhost", "id20569275_linkeddealdb", "dLQUS6KA@dLQUS6KA", "id20569275_linkeddeal");

$PID = $_POST['PID'];
$Quantity = $_POST['Quantity'];
$Total = $_POST['Total'];

$select = "INSERT INTO `OrderItems` (`PID`, `qty`, `TotalPrice`) VALUES ('$PID', '$Quantity', '$Total');";

$result = mysqli_query($con, $select);

if ($result) {
    echo 'Order added';
    $query = "UPDATE `Products` SET `Quantity` = `Quantity` - $Quantity WHERE `PID` = '$PID'";
    $res = mysqli_query($con, $query);
    if ($res) {
        echo 'Quantity updated';
    } else {
        echo 'Failed to update quantity: ' . mysqli_error($con);
    }
} else {
    echo 'Failed to add order: ' . mysqli_error($con);
}

mysqli_close($con);
?>
