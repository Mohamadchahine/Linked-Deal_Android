<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

	$UserID = $_POST['UserID'];
	$query = "DELETE FROM OrderItems WHERE OID IN (SELECT OID FROM Orders WHERE SellerID='$UserID');
                DELETE FROM Orders WHERE SellerID='$UserID';
                    DELETE FROM Products WHERE SellerID='$UserID';
                        DELETE FROM USERS WHERE UserID='$UserID';";

    $result = mysqli_multi_query($con, $query);

	if($result){
		echo "Deleted User!";
	}else{
		echo "Failed!";
	}

	mysqli_close($con);
?>