<?php
$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

$UserID = $_POST["UserID"];
$Password = $_POST["Password"];


$query = "SELECT * FROM USERS WHERE UserID = '$UserID' AND Password = '$Password'";
$queryAdmin = "SELECT * FROM USERS WHERE UserID = '$UserID' AND Password = '$Password' AND UserType = 'Admin'";

$result = mysqli_query($con,$query);

$admincheck = mysqli_query($con,$queryAdmin);

if(mysqli_num_rows($result)>0){
    
	if(mysqli_num_rows($admincheck)>0){
	    echo "success, Admin";
	}else{
		echo "success, Seller";
	}
	//echo "success, Seller";
} else {
	echo "Invalid";
}

?>