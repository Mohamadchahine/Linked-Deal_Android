<?php
	$con = mysqli_connect("localhost","id20569275_linkeddealdb","dLQUS6KA@dLQUS6KA","id20569275_linkeddeal");

    $UserID = strip_tags(addslashes($_GET['UserID']));

	$PName = $_POST['PName'];
	$Category = $_POST['Category']; 
	$Description = $_POST['Description'];
	$Quantity = $_POST['Quantity'];
	$Price = $_POST['Price'];

	$Image = $_POST['Image'];
	 $targetdir = "imageProd/";

	$imagestore = rand()."_".time().".jpeg";
	$targetdir = $targetdir."/".$imagestore;

 	file_put_contents($targetdir,base64_decode($Image));

	$query="INSERT INTO `Products` (`PID`, `PName`, `SellerID`, `Category`, `Description`, `Quantity`, `Price`, `Image`) VALUES (NULL, '$PName', '$UserID', '$Category', '$Description','$Quantity','$Price','$imagestore')";
	$result=mysqli_query($con,$query);

	if($result){
		echo 'Product added';
	}else{
		echo 'failed';
	}

	mysqli_close($con);
?>
